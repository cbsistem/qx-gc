SHA="abababa"
node << __EOF__
var fs = require('fs');
fs.readFile('Manifest.json', function(err, data) {
	var json = JSON.parse(data);
	json.info.checksum = "$SHA";
	fs.writeFile('Manifest2.json', JSON.stringify(json, null, 2));
});
__EOF__
