mkdir dist
rm -f dist/dist.zip
zip -r dist/dist.zip * -x dist
git add dist/dist.zip
git commit -m 'building distribution'
